## vue-sell
# vue2.0高仿饿了么

> sell app

## Build Setup

## 下载项目
git clone https://github.com/pmm0316/vue-sell.git

``` bash
## 在项目目录下install dependencies
npm install

## 运行项目 serve with hot reload at localhost:8080
npm run dev

# 打包 build for production with minification
npm run build
```
## 商品页面
![商品页面](https://github.com/pmm0316/vue-sell/blob/master/src/images/1.PNG)

## 评价页面
![评价页面](https://github.com/pmm0316/vue-sell/blob/master/src/images/2.PNG)

## 商家页面
![商家页面](https://github.com/pmm0316/vue-sell/blob/master/src/images/3.PNG)

## 商品详情
![商品详情](https://github.com/pmm0316/vue-sell/blob/master/src/images/4.PNG)

## 公告详情
![公告详情](https://github.com/pmm0316/vue-sell/blob/master/src/images/5.PNG)
