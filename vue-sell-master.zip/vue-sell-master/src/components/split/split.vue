<template>
  <div class="split"></div>
</template>

<script>
    export default {
        name: ""
    }
</script>

<style lang="stylus" rel="stylesheet/stylus" type="text/stylus" scoped>
  .split
    height 16px
    width 100%
    border-top 1px solid rgba(7,17,27,0.1)
    border-bottom 1px solid rgba(7,17,27,0.1)
    background #f3f5f7
</style>
